# Real-time Object Detection > 2025-10-17 9:06pm
https://universe.roboflow.com/lab-equipment-detector/real-time-object-detection-e6axv

Provided by a Roboflow user
License: CC BY 4.0

